/** Automatically generated file. DO NOT MODIFY */
package com.imei.imeibul;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}